
import { Box, Typography } from "@mui/material";

const Footer = () => {
  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: "rgb(3, 58, 95)",
        color: "white",
        padding: "16px 0",
        textAlign: "center",
        marginTop: "auto",
      }}
    >
      <Typography variant="body2">
        © {new Date().getFullYear()} S-ONE PLATFORM. All Rights Reserved.
      </Typography>
    </Box>
  );
};

export default Footer;
