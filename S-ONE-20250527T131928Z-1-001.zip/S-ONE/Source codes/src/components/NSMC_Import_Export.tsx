import { useEffect, useState } from 'react';
import { db, auth } from '../firebaseConfig';
import { doc, getDoc, collection, getDocs, addDoc, deleteDoc, setDoc } from 'firebase/firestore';
import { DataGrid, GridColDef, GridRenderCellParams, useGridApiRef } from '@mui/x-data-grid';
import { Alert, AlertColor } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { Box, Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, TextField, Typography,
  CircularProgress, MenuItem, Select, InputLabel, FormControl, Chip, Modal, IconButton } from '@mui/material';
import Footer from "./Footer";

interface RowData {
  id: string; // Firestore document ID
  [key: string]: any;
}

const NSMC_Import_Export = () => {
  const [accountType, setAccountType] = useState("");
  const [accountLevel, setAccountLevel] = useState("");
  const [loading, setLoading] = useState(true);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [alertSeverity, setAlertSeverity] = useState<AlertColor>('success');
  const [deleteConfirmationOpen, setDeleteConfirmationOpen] = useState(false);
  const [entryToDelete, setEntryToDelete] = useState<string | null>(null);

  const allFields = [
    'ลำดับ', 'รายการ', 'รายการ(แปลไทย)', 'ใบอนุญาต', 'พิกัด', 'คำอธิบาย', 'อัตราอากร(ร้อยละ)',	'ราคาของ(ตปท.)',	'สกุลเงิน',	
    'อัตราแลกเปลี่ยน',	'ราคาของ(บาท)',	'อากร(บาท)',	'รหัสสินค้าสรรพสามิต',	'อัตราภาษีสรรพสามิต(%)',	'ภาษีสรรพสามิต(บาท)',	
    'ฐานภาษีมูลค่าเพิ่ม',	'ภาษีมูลค่าเพิ่ม(บาท)', 'รวมภาษีและอากร(บาท)', 'วันที่นำเข้า',	'น้ำหนักสุทธิ(KGM)', 'โครงการ',	'ระบบ/งาน',
    'Linkใบขนสินค้า', 'หมายเหตุ'
  ];
  const restrictedFields = [
    'ลำดับ', 'รายการ', 'รายการ(แปลไทย)', 'ใบอนุญาต', 'พิกัด', 'คำอธิบาย', 'อัตราอากร(ร้อยละ)',	'ราคาของ(ตปท.)',	'สกุลเงิน',	
    'อัตราแลกเปลี่ยน',	'ราคาของ(บาท)',	'อากร(บาท)',	'รหัสสินค้าสรรพสามิต',	'อัตราภาษีสรรพสามิต(%)',	'ภาษีสรรพสามิต(บาท)',	
    'ฐานภาษีมูลค่าเพิ่ม',	'ภาษีมูลค่าเพิ่ม(บาท)', 'รวมภาษีและอากร(บาท)', 'วันที่นำเข้า',	'น้ำหนักสุทธิ(KGM)', 'โครงการ',	'ระบบ/งาน',
    'Linkใบขนสินค้า', 'หมายเหตุ'
  ];

  const [originalData, setOriginalData] = useState<RowData[]>([]); // Store original data
  const [tableData, setTableData] = useState<RowData[]>([]);
  const [queryValue, setQueryValue] = useState<string>('');
  const [newEntry, setNewEntry] = useState<Record<string, any>>({});
  const [modalOpen, setModalOpen] = useState<boolean>(false);

  const [editEntry, setEditEntry] = useState<Record<string, any>>({});
  const [isEditing, setIsEditing] = useState(false);

  const gridApiRef = useGridApiRef(); // Initialize useGridApiRef for sorting table

  const fetchUserData = async () => {
    try {
      const user = auth.currentUser;
      if (user) {
        const userDoc = doc(db, 'users', user.uid);
        const docSnap = await getDoc(userDoc);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setAccountType(data.accountType);
          setAccountLevel(data.accountLevel);
        } else {
          console.log('No such document!');
        }
      } else {
        console.log('No user is signed in!');
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    } finally {
      setLoading(false); // Set loading to false after fetching
    }
  };

  // Filter fields based on accountLevel
  const accessibleFields = accountLevel === "manager" ? allFields : restrictedFields;

  // Set initial selected fields
  const [selectedFields, setSelectedFields] = useState<string[]>(accessibleFields);

  const fetchFirestoreData = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'imp-exp-nsmc'));
      const data: RowData[] = [];
      const fieldSet = new Set<string>();
  
      snapshot.forEach((doc) => {
        const docData = { id: doc.id, ...doc.data() }; // Retain the `id` field
        data.push(docData);
        Object.keys(docData).forEach((field) => {
          fieldSet.add(field);
        });
      });
  
      // Filter fields based on accountLevel, but retain `id` field
      const accessibleData = data.map((item) => {
        // Create a new object with the `id` and only the accessible fields
        const filteredItem = Object.fromEntries(
          Object.entries(item).filter(([key]) => accessibleFields.includes(key))
        );
        return { ...filteredItem, id: item.id }; // Add `id` back to the object
      });
  
      setOriginalData(accessibleData);
      setTableData(accessibleData);
    } catch (error) {
      console.error('Error fetching Firestore data:', error);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    fetchUserData();
    fetchFirestoreData();
  }, [accountLevel]);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress /> {/* Display the spinner */}
      </Box>
    );
  }

  const handleQuery = () => {
    if (!queryValue) {
      setTableData(originalData); // Reset to all data if no query
    } else {
      const filteredData = originalData.filter((row) => {
        return selectedFields.some((field) => {
          if (accessibleFields.includes(field)) {
            const value = row[field];
            return typeof value === 'string' && value.toLowerCase().includes(queryValue.toLowerCase());
          }
          return false;
        });
      });
      setTableData(filteredData);
    }
  };
  
  const handleResetQuery = () => {
    if (!queryValue) {
      setTableData(originalData);
    } else {
        setTableData(originalData);
        setQueryValue('');
            }
  };

  const handleSelectAllFields = () => {
    setSelectedFields(accessibleFields); // Select all fields
    gridApiRef.current?.setSortModel([{ field: 'ลำดับ', sort: 'asc' }]);
  };

  const handleUnSelectAllFields = () => {
   setSelectedFields([]); // Unselect all fields
  };

  const handleAddEntry = async () => {
    // Check if all required fields are filled
    const isFormComplete = allFields.every((field) => newEntry[field]);

    if (!isFormComplete) {
      setAlertSeverity('error'); // Set the severity to 'error'
      setAlertMessage('Please fill in all required fields.'); // Set the alert message
      return; // Prevent submission
    }

    try {
      await addDoc(collection(db, 'imp-exp-nsmc'), newEntry);
      fetchFirestoreData(); // Refresh table data after adding
      setNewEntry({}); // Clear the form
      setModalOpen(false); // Close modal

      setAlertSeverity('success'); // Set the severity to 'success'
      setAlertMessage('Entry added successfully!'); // Set the success message
    } catch (error) {
      console.error('Error adding new entry:', error);
      setAlertSeverity('error'); // Set the severity to 'error'
      setAlertMessage('Failed to add new entry. Please try again.'); // Set the error message
    }
  };
  

  const handleInputChange = (field: string, value: any) => {
    setNewEntry((prev) => ({ ...prev, [field]: value }));
  };

  const handleDeleteEntry = async (docId: string) => {
    try {
      // Delete the document directly using its ID
      await deleteDoc(doc(db, 'imp-exp-nsmc', docId));
      fetchFirestoreData(); // Refresh table data after deleting
      setAlertMessage('Deleted successfully!'); // Set the success message
    } catch (error) {
      console.error('Error deleting entry:', error);
    }
  };
  
  const confirmDeleteEntry = async () => {
    if (entryToDelete) {
      await handleDeleteEntry(entryToDelete); // Call your delete function
    }
    setDeleteConfirmationOpen(false); // Close the confirmation dialog
    setEntryToDelete(null); // Reset the entry to delete
  };
  
  const handleEditEntry = (rowData: RowData) => {
    setEditEntry(rowData); // Set the current row data to edit
    setIsEditing(true); // Open the edit modal
  };
  
  const handleUpdateEntry = async () => {
    // Check if all required fields are filled
    const isFormComplete = allFields.every((field) => editEntry[field]);

    if (!isFormComplete) {
      setAlertSeverity('error'); // Set the severity to 'error'
      setAlertMessage('Please fill in all required fields.'); // Set the alert message
      return; // Prevent submission
    }

    try {
      const docRef = doc(db, 'imp-exp-nsmc', editEntry.id); // Get document reference
      await setDoc(docRef, editEntry); // Update the document
      fetchFirestoreData(); // Refresh table data after updating
      setEditEntry({}); // Clear the edit entry
      setIsEditing(false); // Close the modal
      setAlertSeverity('success'); // Set the severity to 'success'
      setAlertMessage('Edited successfully!'); // Set the success message
    } catch (error) {
      console.error('Error updating entry:', error);
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", }}>
       {/* Main Content */}
       <Box sx={{ flex: "1 0 auto", padding: 4 }}>
        <Typography variant="h4" align="center" gutterBottom mt="40px" mb='40px'>
          Import-Export
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 3}}>
          <FormControl variant="outlined" sx={{ mr: 1, ml:1 , minWidth: 150 }}>
            <InputLabel id="field-select-label">Select Fields</InputLabel>
            <Select
              labelId="field-select-label"
              multiple
              value={selectedFields}
              onChange={(e) => setSelectedFields(e.target.value as string[])}
              renderValue={(selected) => (
                <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                  {selected.map((value) => (
                    <Chip key={value} label={value} sx={{ margin: 0.5 }} />
                  ))}
                </Box>
              )}
            >
              {accessibleFields.map((field) => (
                <MenuItem key={field} value={field}>
                  {field}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 3 }}>
          <Button
            variant="outlined"
            color="primary"
            onClick={handleSelectAllFields}
            sx={{ marginLeft: 2 }}
          >
            Select All Fields
          </Button>
          
          <Button
            variant="outlined"
            color="primary"
            onClick={handleUnSelectAllFields} 
            sx={{ marginLeft: 2 }}
          >
            Unselect All fields
          </Button>

        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 3 }}>
          <TextField
            label="Search Keyword"
            variant="outlined"
            value={queryValue}
            onChange={(e) => setQueryValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleQuery(); // Trigger keybaord
              }
            }}
            sx={{ marginRight: 1 }}
          />
          <Button onClick={handleQuery} variant="contained" color="primary" sx={{ marginLeft: 2 }}>
            Search
          </Button>

          <Button onClick={handleResetQuery} variant="contained" color="primary" sx={{ marginLeft: 2 }}>
            Reset Search
          </Button>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', ml: 1 }}>
        {accountType === 'admin' ? (
          <>
            <Button
              variant="outlined"
              color="primary"
              onClick={() => setModalOpen(true)}
              sx={{ mb: 2 }}
            >
              Add New Entry
            </Button>
          </>
        ) : null}
        </Box>

        {alertMessage && (
              <Alert
                severity={alertSeverity}
                
                onClose={() => setAlertMessage(null)} // Close the alert on dismiss
                sx={{ mb: 2 }}
              >
                {alertMessage}
              </Alert>
            )}

        <Modal open={modalOpen || isEditing} onClose={() => { setModalOpen(false); setIsEditing(false); }} sx ={{mt:4}}>
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              padding: 4,
              backgroundColor: 'white',
              margin: 'auto',
              borderRadius: 2,
              width: 400,
              maxHeight: '80vh',
              overflowY: 'auto',
            }}
          >
            <Typography variant="h6" gutterBottom textAlign="center">
              {isEditing ? 'Edit Entry' : 'New Entry Form'}
            </Typography>
            {allFields.map((field) => (
              <TextField
                key={field}
                label={field}
                variant="outlined"
                value={isEditing ? editEntry[field] || '' : newEntry[field] || ''}
                onChange={(e) => isEditing ? setEditEntry(prev => ({ ...prev, [field]: e.target.value })) : handleInputChange(field, e.target.value)}
                sx={{ marginBottom: 2 }}
                required
              />
            ))}
            <Button onClick={isEditing ? handleUpdateEntry : handleAddEntry} variant="contained" color={isEditing ? "primary" : "success"}>
              {isEditing ? 'Update Entry' : 'Submit New Entry'}
            </Button>

            {alertMessage && (
              <Alert
                severity={alertSeverity}
                
                onClose={() => setAlertMessage(null)} // Close the alert on dismiss
                sx={{ mb: 2 }}
              >
                {alertMessage}
              </Alert>
            )}

          </Box>
        </Modal>

        <Box sx={{ height: 600, width: "99%", ml: 1, mb: 20 }}>
          <DataGrid
            apiRef={gridApiRef}
            rows={tableData}
            getRowHeight={() => 'auto'}
            columns={[
              ...selectedFields.map((field): GridColDef => {
                if (field === "Link") {
                  return {
                    field,
                    headerName: "Link",
                    width: 90,
                    align: "center",
                    headerAlign: "center",
                    renderCell: (params: GridRenderCellParams) => {
                      const link = params.value as string; // Extract link value
                      return (
                        <Button
                          variant="contained"
                          color="primary"
                          size="small"
                          onClick={() => window.open(link, "_blank")}
                        >
                          Open
                        </Button>
                      );
                    },
                  };
                }

                // Default fields
                return {
                  field,
                  headerName: field,
                  width: ["ลำดับ", "รายการ (แปลไทย)","พิกัด","คำอธิบาย","สกุลเงิน"].includes(field)
                    ? field === "ลำดับ"
                      ? 85
                      : field === "รายการ (แปลไทย)"
                      ? 250
                      : field === "พิกัด"
                      ? 120
                      : field === "คำอธิบาย"
                      ? 250
                      : field === "คำอธิบาย"
                      ? 85
                      : 80 // Default width for specified fields
                    : 150, // Default width for other fields
                  minWidth: 40,
                  align: "center",
                  headerAlign: "center",
                  cellClassName: "cell-wrap", // Add custom class for wrapping long text
                };
              }),
              ...(accountType === "admin" // for admin only
                ? [
                    {
                      field: "edit",
                      headerName: "Edit",
                      headerAlign: "center",
                      width: 40,
                      renderCell: (params: GridRenderCellParams) => (
                        <IconButton
                          color="primary"
                          onClick={() => handleEditEntry(params.row)}
                        >
                          <EditIcon />
                        </IconButton>
                      ),
                    },
                    {
                      field: "action",
                      headerName: "Delete",
                      headerAlign: "center",
                      width: 70,
                      renderCell: (params: GridRenderCellParams) => (
                        <IconButton
                          color="error"
                          onClick={() => {
                            setEntryToDelete(params.row.id); // Store the entry number to delete
                            setDeleteConfirmationOpen(true); // Open the confirmation dialog
                          }}
                        >
                          <DeleteIcon />
                        </IconButton>
                      ),
                    },
                  ] as GridColDef[] // Assert the type of the array to GridColDef[]
                : []),
            ]}
            initialState={{
              sorting: {
                sortModel: [{ field: "ลำดับ", sort: "asc" }],
              },
              pagination: {
                paginationModel: { pageSize: 25, page: 0 },
              },
            }}
            sx = {{
              "& .MuiDataGrid-root": {
                border: "1px solid #ccc",
                borderRadius: "10px",
              },
              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: "#1976d2",
                color: "#333",
                borderBottom: "2px solid #ccc",
                fontSize: "1rem",
                fontWeight: "bold",
                minHeight: 50,
                textAlign: "center", // Center align header text
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                whiteSpace: "normal",  // Allow wrapping of header text
                wordWrap: "break-word", // Break the word if it's too long
                overflow: "hidden", // Ensure no overflow
                textOverflow: "ellipsis", // Add ellipsis if it's too long
                lineHeight: "1.2", // Adjust line height for readability
                fontWeight: "bold",
              },
              "& .MuiDataGrid-cell": {
                borderRight: "1px solid #ddd", // Add vertical lines
                alignItems: "flex-start", // Align content at the top of the cell

              },
              "& .MuiDataGrid-row": {
                "&:nth-of-type(even)": {
                  backgroundColor: "#f9f9f9", // Alternating row colors
                },
                "&:hover": {
                  backgroundColor: "#f1f1f1", // Hover state
                },
              },
              "& .MuiDataGrid-row.Mui-selected": {
                backgroundColor: "#80deea !important", // Use a light blue or any color for selected row
                "&:hover": {
                  backgroundColor: "#80deea", // Prevent hover color from overriding selected color
                },
              },
              "& .MuiDataGrid-footerContainer": {
                backgroundColor: "#f4f4f4",
              },
              "& .cell-wrap": {
                whiteSpace: "normal", // Enable line breaks
                wordWrap: "break-word", // Break long words
                lineHeight: 2.0,
              },
            }}
          />
        </Box>

        {/* Confirmation Dialog */}
        <Dialog
          open={deleteConfirmationOpen}
          onClose={() => setDeleteConfirmationOpen(false)}
          aria-labelledby="delete-confirmation-dialog-title"
        >
          <DialogTitle id="delete-confirmation-dialog-title">Confirm Delete</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Are you sure you want to delete this entry? This action cannot be undone.
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDeleteConfirmationOpen(false)} color="primary">
              Cancel
            </Button>
            <Button onClick={confirmDeleteEntry} color="error" autoFocus>
              Delete
            </Button>
          </DialogActions>
        </Dialog>
        
        </Box>

      {/* Footer */}
      <Footer />
    </Box>
  );
};

export default NSMC_Import_Export;
