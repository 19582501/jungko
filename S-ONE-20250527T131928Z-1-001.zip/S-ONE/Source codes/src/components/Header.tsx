import { useState, MouseEvent } from "react";
import { auth } from "../firebaseConfig";
import { signOut } from "firebase/auth";
import { AppBar, Toolbar, Typography, Button, IconButton, Snackbar, CircularProgress,
  LinearProgress, Menu, MenuItem } from "@mui/material";
import PersonIcon from "@mui/icons-material/Person";
import { Link, useNavigate } from "react-router-dom";
import logo from "../assets/s-one-platform-logo.png";

// Define types for the props
interface HeaderProps {
  firstName: string;
  userRole: string;
}

const Header = ({ firstName, userRole }: HeaderProps) => {
  const [loading, setLoading] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [nsmcAnchorEl, setNsmcAnchorEl] = useState<null | HTMLElement>(null);
  const [adminAnchorEl, setAdminAnchorEl] = useState<null | HTMLElement>(null);
  const navigate = useNavigate();

  const handleLogout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      setSnackbarMessage("Logged out successfully");
      setSnackbarOpen(true);
      navigate("/login");
    } catch (err: any) {
      setSnackbarMessage("Failed to log out: " + (err?.message || "Unknown error"));
      setSnackbarOpen(true);
    } finally {
      setLoading(false);
    }
  };

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  // NSMC Dropdown Handlers
  const handleNsmcMenuClick = (event: MouseEvent<HTMLElement>) => {
    setNsmcAnchorEl(event.currentTarget);
  };

  const handleNsmcMenuClose = () => {
    setNsmcAnchorEl(null);
  };

  // Admin Dropdown Handlers
  const handleAdminMenuClick = (event: MouseEvent<HTMLElement>) => {
    setAdminAnchorEl(event.currentTarget);
  };

  const handleAdminMenuClose = () => {
    setAdminAnchorEl(null);
  };

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen">
        <LinearProgress
          sx={{ width: "100%", height: "20px", marginTop: "20px" }}
        />
      </div>
    );
  }

  return (
    <>
      <AppBar position="static" sx={{ backgroundColor: "rgb(3, 58, 95)"}}>
        <Toolbar sx={{ justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center" }}>
            {/* Logo */}
            <a
              href="https://sites.google.com/gistda.or.th/s-one-platform"
              style={{ marginRight: 16 }}
            >
              <img src={logo} alt="Logo" style={{ height: 60 }} />
            </a>

            <Link
              to="https://sites.google.com/gistda.or.th/s-one-platform"
              style={{ textDecoration: "none",
               color: "white", marginRight: "20px" }}
            >
              หน้าหลัก
            </Link>

            <Link
              to="/"
              style={{
                textDecoration: "none",
                color: "white",
                marginRight: "20px",
              }}
            >
              ยินดีต้อนรับ
            </Link>

            {(userRole === "GISTDA" || userRole === "admin") && (
              <>
                <Button
                  color="inherit"
                  onClick={handleNsmcMenuClick}
                  sx={{
                    textTransform: "none",
                    fontSize: "16px",
                    fontWeight: "bold",
                    padding: "0",
                    minWidth: "auto",
                    marginRight: "20px",
                    color: "white",
                  }}
                >
                  ศูนย์ผลิตดาวเทียมแห่งชาติ
                </Button>
                <Menu
                  anchorEl={nsmcAnchorEl}
                  open={Boolean(nsmcAnchorEl)}
                  onClose={handleNsmcMenuClose}
                >
                  <MenuItem onClick={handleNsmcMenuClose} component={Link} to="/nsmc-inventory">
                    HW-SW Inventory
                  </MenuItem>
                  <MenuItem onClick={handleNsmcMenuClose} component={Link} to="/nsmc-sat-db">
                    Satellite Database
                  </MenuItem>
                  <MenuItem onClick={handleNsmcMenuClose} component={Link} to="/nsmc-nda">
                    NDA
                  </MenuItem>
                  <MenuItem onClick={handleNsmcMenuClose} component={Link} to="/nsmc-incountry">
                    In-Country
                  </MenuItem>
                  <MenuItem onClick={handleNsmcMenuClose} component={Link} to="/nsmc-import-export">
                    Import-Export
                  </MenuItem>
                </Menu>
              </>
            )}

            {(userRole === "admin" || userRole === "Individual" || userRole === "GISTDA") && (
              <Link
                to="/upload-file"
                style={{ textDecoration: "none", color: "white", marginRight: "20px" }}
              >
                อัพโหลดไฟล์
              </Link>
            )}

            {/* Admin Dropdown Menu - visible only to admin users */}
            {userRole === "admin" && (
              <>
                <Button
                  color="inherit"
                  onClick={handleAdminMenuClick}
                  sx={{
                    textTransform: "none",
                    fontSize: "16px",
                    fontWeight: "bold",
                    padding: "0",
                    minWidth: "auto",
                    marginRight: "20px",
                    color: "white",
                  }}
                >
                  Admin
                </Button>
                <Menu
                  anchorEl={adminAnchorEl}
                  open={Boolean(adminAnchorEl)}
                  onClose={handleAdminMenuClose}
                >
                  <MenuItem onClick={handleAdminMenuClose} component={Link} to="/admin">
                    Approve/Reject Accounts
                  </MenuItem>
                  <MenuItem onClick={handleAdminMenuClose} component={Link} to="/file-storage">
                    Upload Storage
                  </MenuItem>
                </Menu>
              </>
            )}
          </div>

          <div style={{ display: "flex", alignItems: "center" }}>
            <IconButton color="inherit">
              <PersonIcon />
            </IconButton>
            <Typography variant="h6" sx={{ marginLeft: 1 }}>
              {firstName}
            </Typography>
            <Button
              color="inherit"
              onClick={handleLogout}
              sx={{ marginLeft: 2 }}
              disabled={loading}
            >
              {loading ? (
                <>
                  <CircularProgress size={24} color="inherit" sx={{ marginRight: 1 }} />
                  Logging out...
                </>
              ) : (
                "Logout"
              )}
            </Button>
          </div>
        </Toolbar>
      </AppBar>

      <Snackbar
        open={snackbarOpen}
        message={snackbarMessage}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
      />
    </>
  );
};

export default Header;
