import { useEffect, useState } from "react";
import { auth } from "../firebaseConfig";
import { createUserWithEmailAndPassword, sendEmailVerification, signOut } from "firebase/auth";
import { db } from "../firebaseConfig";
import { doc, setDoc } from "firebase/firestore";
import { TextField, Button, Typography, Container, Alert, CircularProgress, Box, List, ListItem, ListItemIcon, ListItemText } from "@mui/material";
import { CheckCircle, Cancel } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { InputAdornment, IconButton } from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import "../index.css";

const Register = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [accountType, setAccountType] = useState("Individual");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const [passwordValidation, setPasswordValidation] = useState({
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    specialChar: false,
  });

  // Check if the user is already signed in
  useEffect(() => {
    const checkUser = async () => {
      if (auth.currentUser) {
        navigate("/");
        return;
      }
    };
    checkUser();
  }, [navigate]);

  // Function to validate password
  const validatePassword = (password: string) => {
    const validations = {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      specialChar: /[!@#$%^&*(),.?":{}|<>]/.test(password),
    };
    setPasswordValidation(validations);
  };

  const handleTogglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };
  
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    // Check if all password validations pass
    if (!Object.values(passwordValidation).every(Boolean)) {
      setError("Password does not meet all the requirements.");
      setLoading(false);
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      await setDoc(doc(db, "users", user.uid), {
        firstName,
        lastName,
        accountType,
        email,
        accountStatus: "pending",
        accountLevel: "staff",
      });

      await sendEmailVerification(user);
      alert("Registration successful! Please check your email to verify your account.");
      await signOut(auth);
      navigate("/login");
    } catch (err: any) {
      setError(`Error: ${err.code}`); 
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="xs">
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        sx={{ mt: 4, mb: 4, p: 4, boxShadow: 3, borderRadius: 2, bgcolor: "background.paper" }}
      >
        <Typography variant="h4" gutterBottom>
          ลงทะเบียน (Register)
        </Typography>

        <form onSubmit={handleRegister} style={{ width: "100%" }}>
          <TextField
            label="First Name"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            fullWidth
            margin="normal"
            required
          />

          <TextField
            label="Last Name"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            fullWidth
            margin="normal"
            required
          />

          <TextField
            select
            label="Account Type"
            value={accountType}
            onChange={(e) => setAccountType(e.target.value)}
            fullWidth
            margin="normal"
            slotProps={{
              select: {
                native: true,
              },
            }}
            required
          >
            <option value="Individual">Individual</option>
            <option value="Organization/Company">Organization/Company</option>
            <option value="GISTDA">GISTDA</option>
          </TextField>

          <TextField
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value.toLocaleLowerCase())}
            fullWidth
            margin="normal"
            required
          />

          <TextField
            label="Password"
            type={showPassword ? "text" : "password"}
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              validatePassword(e.target.value);
            }}
            fullWidth
            margin="normal"
            required
            slotProps={{
              input: {
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={handleTogglePasswordVisibility} edge="end">
                      {showPassword ? <Visibility /> : <VisibilityOff />}
                    </IconButton>
                  </InputAdornment>
                ),
              },
            }}
          />


          {/* Password Policy Checker */}
          <Box sx={{ mt: 2 }}>
            <Typography variant="subtitle1" gutterBottom>
              Password must contain:
            </Typography>
            <List dense>
              <ListItem>
                <ListItemIcon>
                  {passwordValidation.length ? <CheckCircle color="success" /> : <Cancel color="error" />}
                </ListItemIcon>
                <ListItemText primary="At least 8 characters" />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  {passwordValidation.lowercase ? <CheckCircle color="success" /> : <Cancel color="error" />}
                </ListItemIcon>
                <ListItemText primary="At least one lowercase letter" />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  {passwordValidation.uppercase ? <CheckCircle color="success" /> : <Cancel color="error" />}
                </ListItemIcon>
                <ListItemText primary="At least one uppercase letter" />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  {passwordValidation.number ? <CheckCircle color="success" /> : <Cancel color="error" />}
                </ListItemIcon>
                <ListItemText primary="At least one number" />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  {passwordValidation.specialChar ? <CheckCircle color="success" /> : <Cancel color="error" />}
                </ListItemIcon>
                <ListItemText primary="At least one special character (!@#$%^&*)" />
              </ListItem>
            </List>
          </Box>

          <Button type="submit" variant="contained" color="primary" fullWidth sx={{ mt: 2 }} disabled={loading}>
            {loading ? <CircularProgress size={24} color="inherit" /> : "Register"}
          </Button>

          {error && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {error}
            </Alert>
          )}
        </form>

        <Typography align="center" sx={{ mt: 2 }}>
          Already have an account?{" "}
          <Button
            variant="text"
            color="primary"
            onClick={() => navigate("/login")}
            sx={{ fontWeight: "bold", textTransform: "underline" }}
          >
            Login
          </Button>
        </Typography>
      </Box>
    </Container>
  );
};

export default Register;
