import { Typography, Box } from "@mui/material";
import Footer from "./Footer";

const NSMC_SAT_DB = () => {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {/* Main Content */}
      <Box sx={{ flex: "1 0 auto", padding: 4 }}>
        <Box sx={{ textAlign: "center", mt: 5 }}>
          <Typography variant="h4" gutterBottom>
            Satellite Database
          </Typography>

          <Box
            sx={{
              border: "2px solid #ccc",
              borderRadius: "8px",
              overflow: "hidden",
              width: "90%",
              height: "650px",
              margin: "0 auto",
            }}
          >
            <iframe
              src="https://www.itu.int/itu-r/space/apps/public/spaceexplorer/networks-explorer/space-stations"
              width="100%"
              height="100%"
              style={{ border: "none" }}
              title="ITU Space Stations Database"
            ></iframe>
          </Box>
        </Box>
      </Box>

      {/* Footer */}
      <Footer />
    </Box>
    );
};

export default NSMC_SAT_DB;
