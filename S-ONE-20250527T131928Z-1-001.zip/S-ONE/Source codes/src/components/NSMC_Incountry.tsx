import { Box, Typography } from "@mui/material";
import Footer from "./Footer";

const NSMC_Incountry = () => {

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {/* Main Content */}
      <Box sx={{ flex: "1 0 auto", padding: 4 }}>
        <Typography variant="h4" align="center" gutterBottom mt="40px" mb='40px'>
        Satellite Parts and Modules Development in Thailand (in-country project)
        </Typography>

      </Box>
      {/* Footer */}
      <Footer />
    </Box>
  );
};

export default NSMC_Incountry;