import { useEffect, useState } from 'react';
import { auth } from '../firebaseConfig';
import { doc, getDoc, writeBatch, collection } from 'firebase/firestore'; // Import writeBatch
import { db } from '../firebaseConfig';
import { getStorage, ref, getDownloadURL } from 'firebase/storage';
import { useNavigate } from 'react-router-dom';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import * as XLSX from 'xlsx';

const Page2 = () => {
  const [accountType, setAccountType] = useState("");
  const [accountStatus, setAccountStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [accessDenied, setAccessDenied] = useState(false);
  const [tableData, setTableData] = useState<any[][]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const user = auth.currentUser;
        if (user) {
          const userDoc = doc(db, "users", user.uid);
          const docSnap = await getDoc(userDoc);
          if (docSnap.exists()) {
            const data = docSnap.data();
            setAccountType(data.accountType);
            setAccountStatus(data.accountStatus);
          }
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchUserData();
  }, []);

  useEffect(() => {
    if (!loading && accountStatus !== "approved") {
      setAccessDenied(true);
      setTimeout(() => navigate("/"), 3000);
    }
  }, [loading, accountType, accountStatus, navigate]);

  // Fetch and parse Excel data
  useEffect(() => {
    const fetchExcelData = async () => {
      try {
        const storage = getStorage();
        const excelRef = ref(storage, 'DATABASE - NSMC.xlsx'); // Update to your file path
        const url = await getDownloadURL(excelRef);
        const response = await fetch(url);
        const arrayBuffer = await response.arrayBuffer();

        // Parse Excel file
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        // Set data for display
        setTableData(jsonData);

        // Store data into Firestore
        await storeDataInFirestore(jsonData);

      } catch (error) {
        console.error("Error fetching or parsing Excel file:", error);
      }
    };

    if (accountStatus === "approved") {
      fetchExcelData();
    }
  }, [accountStatus]);

  const storeDataInFirestore = async (data: any[][]) => {
    try {
      const batch = writeBatch(db); // Create a new batch
      const headers = data[0]; // First row as headers
  
      data.slice(1).forEach((row) => {
        // Check if all fields are null
        const allFieldsNull = row.every((cell) => cell === null || cell === "");
  
        if (!allFieldsNull) {
          // Define docData with string keys
          const docData: { [key: string]: any } = {}; // Use an index signature for dynamic keys
  
          headers.forEach((header, colIndex) => {
            docData[header] = row[colIndex] !== undefined ? row[colIndex] : null; // Store null for empty cells
          });
  
          // Generate a Firestore auto-ID for the document
          const docRef = doc(collection(db, 'DATABASE-nsmc')); // Adjust collection name
          batch.set(docRef, { ...docData, id: docRef.id }); // Add the generated ID to the document data
        }
      });
      
      await batch.commit(); // Commit the batch
      console.log("Data stored successfully with IDs!");
    } catch (error) {
      console.error("Error storing data in Firestore:", error);
    }
  };
  

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (accessDenied) {
    return (
      <Alert severity="error" sx={{ position: 'absolute', top: 16, left: '50%', transform: 'translateX(-50%)', width: '90%' }} role="alert">
        Access Denied: You do not have permission to view this page. Redirecting to Home...
      </Alert>
    );
  }

  return (
    <div>
      <div style={{ textAlign: 'center', marginTop: '20px' }}>
        <h2>Welcome to S-ONE PLATFORM</h2>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
          <thead>
            <tr>
              {tableData[0] && tableData[0].map((header, index) => (
                <th key={index} style={{ border: '1px solid #ddd', padding: '8px' }}>
                  {header === undefined || header === "" ? "-" : header} {/* Replace empty cells with "-" */}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tableData.slice(1).map((row, rowIndex) => (
              <tr key={rowIndex}>
                {row.map((cell, cellIndex) => (
                  <td key={cellIndex} style={{ border: '1px solid #ddd', padding: '8px' }}>
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Page2;
