import React, { useEffect, useState } from 'react';
import { Divider, Container, Box, Stack, Radio, RadioGroup, FormControl, FormControlLabel, TextField, Typography, Button, FormLabel} from '@mui/material'
import { getStorage, ref, getDownloadURL } from "firebase/storage";
import dayjs, { Dayjs } from 'dayjs';
import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";
import { toWords } from 'number-to-words';
import Footer from "./Footer";

const NSMC_NDA_Request = () => {
  // State for form data
  const [formData, setFormData] = useState({
    nda_purpose: "",
    owner: "",
    phone_number: "",
    process_owner: "",
    company_name: "",
    company_name_acronym: "Company",
    company_address: "",
    company_contact_name: "",
    company_contact_email: "",
    laws: "",
    agreements: "",
    duration: "three (3) years",
    duration_other: "",
    gistda_res_name: "",
    gistda_res_email: "",
    company_res_name: "",
    company_res_email: "",
    company_res_address: "",
    company_signer: "",
    company_signer_position: "",
    company_witness: "",
    company_witness_position: "",
    signature: "",
    signature_fullname: "",
    signature_position: "",
    day: "",
    month: "",
    year: "",
    time_stamp: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
  
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  
  // Handle radio button change for the duration selection
  const handleDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;

    setFormData((prevState) => ({
      ...prevState,
      duration: value, // Set the selected predefined duration or "Other"
      duration_other: value === '' ? prevState.duration_other : '', // Clear custom input if not "Other"
    }));
  };

  const [rawDurationInput, setRawDurationInput] = useState<string>("");

  const handleOtherDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
  
    // Allow the user to type freely and store the raw input
    setRawDurationInput(value);
  
    // Do not update the formatted value until validation
    setFormData((prevState) => ({
      ...prevState,
      duration_other: value, // Temporary raw input
    }));
  };
  
  const handleOtherDurationBlur = () => {
    const numericValue = parseInt(rawDurationInput, 10);
  
    if (!isNaN(numericValue) && numericValue > 0) {
      const textValue = toWords(numericValue).toLowerCase();
      const formattedValue = `${textValue} (${numericValue}) ${numericValue === 1 ? "year" : "years"}`;
      setFormData((prevState) => ({
        ...prevState,
        duration_other: formattedValue, // Save formatted value on blur
      }));
    }
  };

  const [signDate] = useState<Dayjs | null>(dayjs()); // Default to current date

  // Update formData state with day, month, and year from signDate
  useEffect(() => {
    if (signDate) {
      setFormData((prevState) => ({
        ...prevState,
        day: signDate.format('D'), // Extract day
        month: signDate.format('MMMM'), // Extract month
        year: signDate.format('YYYY'), // Extract year in Buddhist Era
        time_stamp: signDate.format('hh:mm:ss A')
      }));
    }
  }, [signDate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
  
    // Fetch NDA Request template from Firebase Storage
    const storage = getStorage();
    const fileRef = ref(storage, "NDA Template.docx");

    try {
      const url = await getDownloadURL(fileRef);
      const response = await fetch(url);
      const arrayBuffer = await response.arrayBuffer();

      // Populate .docx file with form data
      const zip = new PizZip(arrayBuffer);
      const doc = new Docxtemplater(zip, { paragraphLoop: true, linebreaks: true });

      doc.setData(formData);
      doc.render();

      const blob = doc.getZip().generate({ type: "blob" });
      const downloadUrl = window.URL.createObjectURL(blob);

      const fileName = `NDA.###.${formData.year} ${formData.company_name}.docx`;

      const a = document.createElement("a");
      a.href = downloadUrl;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (error) {
      console.error("Error generating Request document:", error);
      alert("Failed to generate the NDA document. Please try again.");
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      <Box sx={{ flex: "1 0 auto", padding: 4 }}>
        <Container maxWidth="md">
          <Box
            display="flex"
            flexDirection="column"
            alignItems="center"
            sx={{ mt: 4, p: 4, boxShadow: 3, borderRadius: 2, bgcolor: "background.paper" }}
          >
            <form onSubmit={handleSubmit} style={{ width: "100%" }}>
              <Stack spacing={3}>
                <Typography variant="h4" gutterBottom sx={{ textAlign: 'center' }}>
                  Request NDA Form
                </Typography>

                {/* Section 1: Purpose */}
                <Typography variant="h5" gutterBottom >
                  ที่มาและจุดประสงค์ในการขอทำ NDA
                </Typography>
                <TextField
                  fullWidth
                  label="ที่มาและจุดประสงค์"
                  name="nda_purpose"
                  value={formData.nda_purpose}
                  onChange={handleChange}
                  helperText="เช่น เพื่อต้องการขอรายละเอียดข้อมูลเพิ่มเติมด้านคุณสมบัติทางเทคนิคของโมดูลและใบเสนอราคาของโมดูล Power Conditioning and Distribution Unit (PCDU) ภายใต้การพัฒนาดาวเทียม THEOS-3"
                  multiline
                  rows={4}
                />

                <Divider sx={{ my: 2 }} />

                {/* Section 2: Process Details */}
                <Typography variant="h5" gutterBottom>
                  การดำเนินเรื่อง
                </Typography>
                <Stack direction="row" spacing={3}>
                  <TextField
                    fullWidth
                    label="เจ้าของเรื่อง"
                    name="owner"
                    value={formData.owner}
                    onChange={handleChange}
                    helperText="ชื่อเต็ม (ภาษาไทย) เช่น กษิดิ์เดช ศรีสุทธะ"
                  />
                  <TextField
                    fullWidth
                    label="หมายเลขโทรศัพท์"
                    name="phone_number"
                    value={formData.phone_number}
                    onChange={handleChange}
                    helperText="เช่น 0812345678"
                  />
                </Stack>
                <FormControl component="fieldset">
                  <FormLabel component="legend">การดำเนินเรื่อง</FormLabel>
                  <RadioGroup
                    name="process_owner"
                    value={formData.process_owner}
                    onChange={handleChange}
                    row
                  >
                    <FormControlLabel
                      value="เจ้าของเรื่องดำเนินการเอง"
                      control={<Radio />}
                      label="เจ้าของเรื่องดำเนินการเอง"
                    />
                    <FormControlLabel
                      value="ให้ ฝสก. เป็นผู้ช่วยดำเนินการประสาน"
                      control={<Radio />}
                      label="ให้ ฝสก. เป็นผู้ช่วยดำเนินการประสาน"
                    />
                  </RadioGroup>
                </FormControl>

                <Divider sx={{ my: 2 }} />

                {/* Section 3: NDA Details */}
                <Typography variant="h5" gutterBottom>
                  ข้อมูลสำหรับ NDA (English Only)
                </Typography>
                <TextField
                  fullWidth
                  label="Company Full Name"
                  name="company_name"
                  value={formData.company_name}
                  onChange={handleChange}
                  helperText="e.g., Surrey Satellite Technology Limited"
                />
                <TextField
                  fullWidth
                  label="Company Acronym Name"
                  name="company_name_acronym"
                  value={formData.company_name_acronym}
                  onChange={handleChange}
                  helperText="e.g., SSTL if not applicable. Leave it as Company"
                />
                <TextField
                  fullWidth
                  label="Company Address"
                  name="company_address"
                  value={formData.company_address}
                  onChange={handleChange}
                  helperText="e.g., Tycho House, 20 Stephenson Road, Surrey Research Park, Guildford, GU2 7YE, United Kingdom"
                  multiline
                  rows={2}
                />
                <TextField
                    fullWidth
                    label="Company is under the law of ..."
                    name="laws"
                    value={formData.laws}
                    onChange={handleChange}
                    helperText="e.g., England"
                  />
                <TextField
                  fullWidth
                  label="GISTDA and Company have agreed to"
                  name="agreements"
                  value={formData.agreements}
                  onChange={handleChange}
                  helperText="e.g., exchange technical information related to spacecraft mechanisms"
                  multiline
                  rows={3}
                />

                {/* Duration */}
                <Typography variant="h6" gutterBottom>
                  Duration of the Agreement
                </Typography>

                {/* Radio buttons for predefined duration options */}
                <FormControl component="fieldset">
                  <RadioGroup
                    name="duration"
                    value={formData.duration}
                    onChange={handleDurationChange}
                    row
                  >
                    <FormControlLabel value="one (1) year" control={<Radio />} label="1 year" />
                    <FormControlLabel value="two (2) years" control={<Radio />} label="2 years" />
                    <FormControlLabel value="three (3) years" control={<Radio />} label="3 years" />
                    <FormControlLabel value="four (4) years" control={<Radio />} label="4 years" />
                    <FormControlLabel value="five (5) years" control={<Radio />} label="5 years" />
                    <FormControlLabel value="" control={<Radio />} label="Other" />
                  </RadioGroup>
                </FormControl>

                {/* If "Other" is selected, display a text field to specify the custom duration */}
                {formData.duration === '' && (
                  <TextField
                    fullWidth
                    label="Please specify the duration"
                    value={formData.duration_other}
                    onChange={handleOtherDurationChange}
                    onBlur={handleOtherDurationBlur}
                  />
                )}

                <Divider sx={{ my: 2 }} />

                {/* Section 4: Authorized Officers */}
                <Typography variant="h5" gutterBottom>
                  Authorized Officers or Representatives
                </Typography>

                {/* GISTDA */}
                <Typography variant="h6" gutterBottom>
                  GISTDA
                </Typography>
                <Stack direction="row" spacing={3}>
                  <TextField
                    fullWidth
                    label="Full Name"
                    name="gistda_res_name"
                    value={formData.gistda_res_name}
                    onChange={handleChange}
                    helperText="e.g., Kasidet Srisutha"
                  />
                  <TextField
                    fullWidth
                    label="Email"
                    name="gistda_res_email"
                    value={formData.gistda_res_email}
                    onChange={handleChange}
                    helperText="e.g., kasidet.sri@gistda.or.th"
                  />
                </Stack>

                {/* Company */}
                <Typography variant="h6" gutterBottom>
                  Company
                </Typography>
                <Stack direction="row" spacing={3}>
                  <TextField
                    fullWidth
                    label="Full Name"
                    name="company_res_name"
                    value={formData.company_res_name}
                    onChange={handleChange}
                    helperText="e.g., Mikel Arteta"
                  />
                  <TextField
                    fullWidth
                    label="Email"
                    name="company_res_email"
                    value={formData.company_res_email}
                    onChange={handleChange}
                    helperText="e.g., mikel.art@company.com"
                  />
                </Stack>
                <TextField
                  fullWidth
                  label="Address of Representative of the Company "
                  name="company_res_address"
                  value={formData.company_res_address}
                  onChange={handleChange}
                  helperText="e.g., 666 Fillmore Ave, Seattle, WA, 95054, US"
                />

                <Divider sx={{ my: 2 }} />

                {/* Section 5: Signatory */}
                <Typography variant="h5" gutterBottom>
                  Signatory for NDA
                </Typography>

                {/* For Company */}
                <Typography variant="h6" gutterBottom>
                  For Company
                </Typography>
                <Stack direction="row" spacing={3}>
                  <TextField
                    fullWidth
                    label="Full Name"
                    name="company_signer"
                    value={formData.company_signer}
                    onChange={handleChange}
                    helperText="ผู้ลงนามหลัก e.g., Patrick Weston"
                  />
                  <TextField
                    fullWidth
                    label="Position"
                    name="company_signer_position"
                    value={formData.company_signer_position}
                    onChange={handleChange}
                    helperText="e.g., Managing Director"
                  />
                </Stack>

                {/* Witness */}
                <Typography variant="h6" gutterBottom>
                  Witness (Company)
                </Typography>
                <Stack direction="row" spacing={3}>
                  <TextField
                    fullWidth
                    label="Full Name"
                    name="company_witness"
                    value={formData.company_witness}
                    onChange={handleChange}
                    helperText="พยาน e.g., John Andrews"
                  />
                  <TextField
                    fullWidth
                    label="Position"
                    name="company_witness_position"
                    value={formData.company_witness_position}
                    onChange={handleChange}
                    helperText="e.g., Chief Technical Officer"
                  />
                </Stack>

                <Divider sx={{ my: 2 }} />

                {/* Section 6: Sign the form */}
                <Stack spacing={2}>
                {/* Section Title */}
                <Typography variant="h5" gutterBottom>
                  ลงนามสำหรับผู้ขอ
                </Typography>

                <TextField
                  fullWidth
                  name="signature_fullname"
                  label="ชื่อเต็ม (ภาษาไทย)"
                  value={formData.signature_fullname}
                  onChange={handleChange}
                  helperText="เช่น กษิดิ์เดช ศรีสุทธะ"
                />

                <TextField
                  fullWidth
                  name="signature_position"
                  label="ตำแหน่ง/ฝ่าย"
                  value={formData.signature_position}
                  onChange={handleChange}
                  helperText="เช่น วิศวกร/ฝสก."
                />
                
                <Typography variant="h6" gutterBottom sx={{ wordBreak: "break-word" }}>
                  ผู้ขอลงนาม ณ วันที่ : {formData.day} {formData.month} {formData.year} {""}
                  {formData.time_stamp}
                </Typography>

                </Stack>

                {/* Submit Button */}
                <Button variant="contained" color="primary" type="submit" fullWidth>
                  Generate NDA Template
                </Button>
              </Stack>
            </form>
          </Box>
        </Container>
      </Box>

      {/* Footer */}
      <Footer />
    </Box>
  );
};

export default NSMC_NDA_Request;
