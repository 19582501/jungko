import { useEffect, useState } from 'react';
import { db, storage } from '../firebaseConfig';
import { doc, collection, getDocs, deleteDoc } from 'firebase/firestore';
import { ref, getDownloadURL, deleteObject } from 'firebase/storage';
import { IconButton, Typography, Box, CircularProgress, Container, Paper, Alert, AlertColor } from '@mui/material';
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import DownloadIcon from '@mui/icons-material/Download';
import DeleteIcon from '@mui/icons-material/Delete';
import dayjs from 'dayjs';
import Footer from "./Footer";

interface FileData {
  id: string;
  fileName: string;
  uniqueFileName: string;
  uploaderFirstName: string;
  uploaderLastName: string;
  uploaderEmail: string;
  uploadDate: Date;
  filePath: string;
}

const FileStorage = () => {
  const [files, setFiles] = useState<FileData[]>([]);
  const [loading, setLoading] = useState(true);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [alertSeverity, setAlertSeverity] = useState<AlertColor>('success');

  useEffect(() => {
    const fetchFiles = async () => {
      try {
        const filesCollection = collection(db, 'uploads');
        const filesSnapshot = await getDocs(filesCollection);
        
        const filesList = filesSnapshot.docs.map(doc => ({
          id: doc.id,
          fileName: doc.data().fileName || '',
          uploaderFirstName: doc.data().uploaderFirstName || '',
          uploaderLastName: doc.data().uploaderLastName || '',
          uploaderEmail: doc.data().uploaderEmail || '',
          uploadDate: doc.data().uploadDate?.toDate() || new Date(0),
          filePath: doc.data().filePath || '',
        })) as FileData[];

        setFiles(filesList);
      } catch (error) {
        console.error("Error fetching files:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchFiles();
  }, []);

  const handleDownload = async (filePath: string) => {
    setAlertMessage("");
    try {
      // Get the download URL from Firebase Storage
      const url = await getDownloadURL(ref(storage, filePath));
  
      // Fetch the file as a Blob to ensure clean download
      const response = await fetch(url);
      const blob = await response.blob();
  
      // Extract a clean file name from the filePath
      const fileName = filePath.split("/").pop()?.split("-")[0] || "downloaded_file.docx";
  
      // Create an object URL for the Blob
      const downloadUrl = window.URL.createObjectURL(blob);
  
      // Create a temporary anchor element to trigger download
      const anchor = document.createElement("a");
      anchor.href = downloadUrl;
      anchor.download = fileName; // Set the clean file name
      document.body.appendChild(anchor);
      anchor.click();
  
      // Clean up: revoke object URL and remove the anchor
      window.URL.revokeObjectURL(downloadUrl);
      document.body.removeChild(anchor);
  
      setAlertMessage("File downloaded successfully!");
      setAlertSeverity("success");
    } catch (error) {
      console.error("Error downloading file:", error);
      setAlertMessage("File download failed.");
      setAlertSeverity("error");
    }
  };
  
  const handleDelete = async (fileId: string, filePath: string) => {
    setAlertMessage("");
    try {
      await deleteObject(ref(storage, filePath));
      await deleteDoc(doc(db, 'uploads', fileId));
      setFiles(files.filter(file => file.id !== fileId));
      setAlertMessage("File deleted successfully!");
      setAlertSeverity("success");
    } catch (error) {
      console.error("Error deleting file:", error);
      setAlertMessage("File deletion failed.");
      setAlertSeverity("error");
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <CircularProgress />
      </Box>
    );
  }

  const columns: GridColDef[] = [
    {
      field: "fileName",
      headerName: "File Name",
      minWidth: 350,
      sortable: true,
    },
    {
      field: "uploader",
      headerName: "Uploader",
      flex: 1,
      sortable: true,
    },
    {
      field: "email",
      headerName: "Email",
      flex: 1,
      sortable: true,
    },
    {
      field: "uploadDate",
      headerName: "Upload Date",
      minWidth: 150,
      sortable: true,
    },
    {
      field: "actions",
      headerName: "Actions",
      flex: 1,
      sortable: false,
      renderCell: (params) => (
        <>
          <IconButton
            onClick={() => handleDownload(params.row.filePath)}
            color="primary"
          >
            <DownloadIcon />
          </IconButton>
          <IconButton
            onClick={() => handleDelete(params.row.id, params.row.filePath)}
            color="secondary"
          >
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ];

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {/* Main Content */}
      <Box sx={{ flex: "1 0 auto", padding: 4 }}>
        <Box textAlign="center">
          <Typography variant="h4" gutterBottom>
            Admin File Management
          </Typography>

          {/* Display alert message if present */}
          {alertMessage && (
            <Alert severity={alertSeverity} onClose={() => setAlertMessage(null)} sx={{ mb: 2 }}>
              {alertMessage}
            </Alert>
          )}
        </Box>

      <Container>
          <Paper sx={{ height: 500, width: "100%" }}>
            <DataGrid
              rows={files
                .map((file, index) => ({
                  id: file.id || index,
                  fileName: file.fileName,
                  uploader: `${file.uploaderFirstName} ${file.uploaderLastName}`,
                  email: file.uploaderEmail,
                  uploadDate: dayjs(file.uploadDate).format(
                    "DD/MM/YYYY HH:mm:ss"
                  ),
                  filePath: file.filePath,
                }))}
              columns={columns}
        
              initialState={{
                sorting: {
                  sortModel: [{ field: "uploadDate", sort: "asc" }],
                },
                pagination: {
                  paginationModel: { pageSize: 25, page: 0 },
                },
              }}

            />
          </Paper>
      </Container>

      </Box>

      {/* Footer */}
      <Footer />      
    </Box>
  );
};

export default FileStorage;
