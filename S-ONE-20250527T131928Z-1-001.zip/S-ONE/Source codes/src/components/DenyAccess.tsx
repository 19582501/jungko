import { Container, Typography, Button, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";

const DenyAccess = () => {
  const navigate = useNavigate();

  return (
    <Box sx={{ textAlign: "center", mt: 10 }}>
      <Container maxWidth="sm">
        <Typography variant="h4" align="center" sx={{ mt: 4 }}>
          Access Denied
        </Typography>
        <Typography variant="body1" align="center" sx={{ mt: 2 }}>
          - Your account status has not approved for access. (Wait for approval)
        </Typography>

        <Typography variant="body1" align="center" sx={{ mt: 2 }}>
          - You Account email has not verified. (Check your inbox email)
        </Typography>
      </Container>

      <Button 
        variant="contained" 
        color="primary" 
        onClick={() => navigate("/login")}
        sx={{ mt: 4, mb: 4 }}
      >
        Back to Login Page
      </Button>
    </Box>
  );
};

export default DenyAccess;
