import { useEffect } from "react";
import { auth } from "../firebaseConfig";
import { signOut } from "firebase/auth";

const INACTIVITY_TIMEOUT = 30 * 60 * 1000; // 30 minutes
const LAST_ACTIVITY_KEY = "lastActivityTime";

const useSessionHandler = () => {
  useEffect(() => {
    let inactivityTimer: NodeJS.Timeout | null = null;

    const handleSignOut = async () => {
      await signOut(auth);
      window.location.reload(); // Redirect to login
      console.log("Automatically signed out due to inactivity for 30 mins!");
    };

    const startInactivityTimer = () => {
      inactivityTimer = setTimeout(() => {
        handleSignOut();
      }, INACTIVITY_TIMEOUT);
    };

    const resetTimer = () => {
      if (inactivityTimer) clearTimeout(inactivityTimer);
      const currentTime = Date.now();
      localStorage.setItem(LAST_ACTIVITY_KEY, currentTime.toString()); // Save the last activity time
      startInactivityTimer();
    };

    const checkSessionExpiry = () => {
      const lastActivityTime = localStorage.getItem(LAST_ACTIVITY_KEY);
      if (lastActivityTime) {
        const elapsedTime = Date.now() - parseInt(lastActivityTime, 10);
        if (elapsedTime > INACTIVITY_TIMEOUT) {
          handleSignOut(); // Sign out immediately if the session expired
        }
      }
    };

    // Check for session expiry on page load
    checkSessionExpiry();

    // Add event listeners for user activity
    const events = ["mousemove", "keydown", "click", "scroll"];
    events.forEach((event) => window.addEventListener(event, resetTimer));

    // Start the inactivity timer
    resetTimer();

    // Cleanup
    return () => {
      if (inactivityTimer) clearTimeout(inactivityTimer);
      events.forEach((event) => window.removeEventListener(event, resetTimer));
    };
  }, []);

  return null; // No UI returned since the logic is background-only
};

export default useSessionHandler;
