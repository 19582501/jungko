import { useEffect, useState } from "react";
import { auth, db } from "../firebaseConfig";
import { signInWithEmailAndPassword } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { TextField, Button, Typography, Container, Alert, CircularProgress, Box, Paper, LinearProgress } from "@mui/material";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { InputAdornment, IconButton } from "@mui/material";
import "../index.css";

const Login: React.FC = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [checkingStatus, setCheckingStatus] = useState(true);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [showPassword, setShowPassword] = useState(false);

  // Check if the user is already signed in
  useEffect(() => {
    const checkUser = async () => {
      if (auth.currentUser) {
        // User is already signed in; redirect to home page
        navigate("/");
        return;
      }
      setCheckingStatus(false); // Mark as done checking
    };

    checkUser();
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    setCheckingStatus(true);
    
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      const userDocRef = doc(db, "users", user.uid);
      const docSnap = await getDoc(userDocRef);

      if (docSnap.exists()) {
        const userData = docSnap.data();
        const userAccountStatus = userData.accountStatus;
        
        if (userAccountStatus === "approved" && user.emailVerified) {
          // Check for the "redirect" query parameter and navigate accordingly
          const redirectPath = searchParams.get("redirect") || "/";
          navigate(redirectPath); // Redirect to intended page or home
        } else {
          await auth.signOut();
          setError("Your account is not active or your email is not verified.");
          navigate("/denyaccess"); // Redirect to deny access page
        }
      } else {
        setError("Account details not found. Please contact support.");
      }
    } catch (err: any) {
      console.log(err.code)
      setError(`Error: ${err.code}`);    
      } 
      finally {
      setLoading(false);
      setCheckingStatus(false);
    }
  };
  
  return (
    <Container maxWidth="xs" sx={{ mt: 15 }}>
      <Paper elevation={6} sx={{ p: 4, borderRadius: 2 }}>
        {loading && <LinearProgress sx={{ mb: 2 }} />}

        <form onSubmit={handleLogin}>
          <Typography variant="h4" align="center" gutterBottom>
            เข้าสู่ระบบ (Login)
          </Typography>

          <TextField
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            fullWidth
            margin="normal"
            required
          />

          <TextField
            label="Password"
            type={showPassword ? "text" : "password"} // Toggle password visibility
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            fullWidth
            margin="normal"
            required
            slotProps={{
              input: {
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPassword((prev) => !prev)} // Toggle showPassword
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />} {/* Toggle icons */}
                    </IconButton>
                  </InputAdornment>
                ),
              },
            }}
          />

          <Box sx={{ display: "flex", justifyContent: "center", mt: 2, mb: 1 }}>
            {checkingStatus && <CircularProgress size={24} />}
          </Box>

          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            disabled={loading || checkingStatus}
            sx={{ mt: 2, fontSize: "1rem", py: 1 }}
          >
            {loading ? "Logging in..." : "Login"}
          </Button>

          {error && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {error}
            </Alert>
          )}

          <Typography align="center" sx={{ mt: 2 }}>
            Do not have an account?{" "}
            <Button
              variant="text"
              color="primary"
              onClick={() => navigate("/register")}
              sx={{
                fontWeight: "bold",
                textTransform: "underline",
                backgroundColor: "none",
                "&:hover": {
                  backgroundColor: "rgb(202, 225, 250)",
                },
              }}
            >
              Register
            </Button>
          </Typography>
        </form>
      </Paper>
    </Container>
  );
};

export default Login;
