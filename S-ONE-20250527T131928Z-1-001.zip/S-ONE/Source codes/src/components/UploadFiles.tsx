import { useEffect, useState } from 'react';
import { auth } from '../firebaseConfig';
import { doc, getDoc, setDoc, collection, query, where, getDocs, deleteDoc } from 'firebase/firestore';
import { db, storage } from '../firebaseConfig';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { Alert, AlertColor, Box,Button, CircularProgress, Container, Paper, Typography} from '@mui/material';
import { Timestamp } from 'firebase/firestore';
import { IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import DownloadIcon from '@mui/icons-material/Download';
import { DataGrid, GridColDef } from "@mui/x-data-grid";

import { v4 as uuidv4 } from 'uuid';
import dayjs from 'dayjs';
import Footer from "./Footer";

interface FileData {
  id: string;
  fileName: string;
  uniqueFileName: string;
  uploaderFirstName: string;
  uploaderLastName: string;
  uploaderEmail: string;
  uploadDate: Date;
  filePath: string;
}

const UploadFiles = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(true);
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [alertSeverity, setAlertSeverity] = useState<AlertColor>('success');
  const [files, setFiles] = useState<FileData[]>([]);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const user = auth.currentUser;
        if (user) {
          const userDoc = doc(db, "users", user.uid);
          const docSnap = await getDoc(userDoc);
          if (docSnap.exists()) {
            const data = docSnap.data();
            setFirstName(data.firstName);
            setLastName(data.lastName);
            setEmail(data.email);
          } else {
            console.log("No such document!");
          }
        } else {
          console.log("No user is signed in!");
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchUserData();
  }, []);

  // Fetch files uploaded by the current user
  useEffect(() => {
    const fetchUserFiles = async () => {
      try {
        const user = auth.currentUser;
        if (user) {
          const filesQuery = query(
            collection(db, "uploads"),
            where("uploaderEmail", "==", user.email) // Match files to the logged-in user
          );
          const querySnapshot = await getDocs(filesQuery);
          const userFiles = querySnapshot.docs.map(doc => ({
            id: doc.id,
            fileName: doc.data().fileName || '',
            uniqueFileName: doc.data().uniqueFileName || '',
            uploaderFirstName: doc.data().uploaderFirstName || '',
            uploaderLastName: doc.data().uploaderLastName || '',
            uploaderEmail: doc.data().uploaderEmail || '',
            uploadDate: doc.data().uploadDate?.toDate() || new Date(0),
            filePath: doc.data().filePath || '',
          })) as FileData[];

          setFiles(userFiles);
        }
      } catch (error) {
        console.error("Error fetching user files:", error);
      }
    };

    fetchUserFiles();
  }, [email]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0] || null;
    setAlertMessage("")
    if (selectedFile) {
      const isPdf = selectedFile.type === "application/pdf";
      const isDoc =
        selectedFile.type === "application/msword" ||
        selectedFile.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document"; // .docx MIME type
      
      // Check if the filename contains a dash
      if (selectedFile.name.includes("-")) {
        setAlertMessage("Filename cannot contain a dash (-). Please rename the file or use . # _ instead");
        setAlertSeverity("error");
        setFile(null); // Clear the file
        return; // Stop further processing
      }

      if (isPdf || isDoc) {
        setFile(selectedFile);
      } else {
        setAlertMessage("Please select a valid PDF, DOC, or DOCX file.");
        setAlertSeverity("error");
        setFile(null);
      }
    }
  };
  
  const handleUpload = async () => {
    if (file) {
      setUploading(true);
      const uniqueFileName = `${file.name}-${uuidv4()}`; // Generate a unique filename with UUID
      const storageRef = ref(storage, `uploads/${uniqueFileName}`);

      try {
        await uploadBytes(storageRef, file);

        // Save metadata in Firestore
        const fileMetadata = {
          fileName: file.name,
          uniqueFileName, // Store the unique file name in Firestore
          uploaderFirstName: firstName,
          uploaderLastName: lastName,
          uploaderEmail: email,
          uploadDate: Timestamp.now(),
          filePath: `uploads/${uniqueFileName}` // Firebase Storage path
        };
        await setDoc(doc(collection(db, "uploads")), fileMetadata);

        setAlertMessage("File uploaded successfully!");
        setAlertSeverity("success");
        setFile(null);

        // Refresh file list
        setFiles([...files, { id: uuidv4(), ...fileMetadata, uploadDate: fileMetadata.uploadDate.toDate() }]);
      } catch (error) {
        console.error("Error uploading file:", error);
        setAlertMessage("File upload failed. Please try again.");
        setAlertSeverity("error");
      } finally {
        setUploading(false);
      }
    } else {
      setAlertMessage("Please select a file to upload.");
      setAlertSeverity("error");
    }
  };

  const handleDownload = async (filePath: string) => {
    setAlertMessage("");
    try {
      // Get the download URL from Firebase Storage
      const url = await getDownloadURL(ref(storage, filePath));
  
      // Fetch the file as a Blob to ensure clean download
      const response = await fetch(url);
      const blob = await response.blob();

      // Extract a clean file name from the filePath
      const fileName = filePath.split("/").pop()?.split("-")[0] || "downloaded_file.docx";

      // Create an object URL for the Blob
      const downloadUrl = window.URL.createObjectURL(blob);
  
      // Create a temporary anchor element to trigger download
      const anchor = document.createElement("a");
      anchor.href = downloadUrl;
      anchor.download = fileName; // Set the clean file name
      document.body.appendChild(anchor);
      anchor.click();
  
      // Clean up: revoke object URL and remove the anchor
      window.URL.revokeObjectURL(downloadUrl);
      document.body.removeChild(anchor);
  
      setAlertMessage("File downloaded successfully!");
      setAlertSeverity("success");
    } catch (error) {
      console.error("Error downloading file:", error);
      setAlertMessage("File download failed.");
      setAlertSeverity("error");
    }
  };
  
  const handleDelete = async (fileId: string, filePath: string) => {
    setAlertMessage("")
    try {
      await deleteObject(ref(storage, filePath));
      await deleteDoc(doc(db, 'uploads', fileId));
      setFiles(files.filter(file => file.id !== fileId));
      setAlertMessage("File deleted successfully!");
      setAlertSeverity("success");
      setDeleting(true)
    } catch (error) {
      console.error("Error deleting file:", error);
      setAlertMessage("File deletion failed.");
      setAlertSeverity("error");
    }
    setDeleting(false)
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }


  const columns: GridColDef[] = [
    {
      field: "fileName",
      headerName: "File Name",
      minWidth: 350,
      sortable: true,
    },
    {
      field: "uploadDate",
      headerName: "Upload Date",
      minWidth: 150,
      sortable: true,
    },
    {
      field: "actions",
      headerName: "Actions",
      flex: 1,
      sortable: false,
      renderCell: (params) => (
        <>
          <IconButton
            onClick={() => handleDownload(params.row.filePath)}
            color="primary"
          >
            <DownloadIcon />
          </IconButton>
          <IconButton
            onClick={() => handleDelete(params.row.id, params.row.filePath)}
            color="secondary"
          >
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ];

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", }}>
      
      {/* Main Content */}
      <Box sx={{ flex: "1 0 auto", padding: 4 }}>
        <Box textAlign="center" sx={{ p: 4 }}>
          <Typography variant="h4" gutterBottom>
            Upload and Manage Your Files
          </Typography>

          <input
            accept=".pdf,.doc,.docx"
            id="upload-file"
            type="file"
            style={{ display: "none" }}
            onChange={handleFileChange}
          />

          <label htmlFor="upload-file">
            <Button
              variant="contained"
              component="span"
              color="primary"
              sx={{ mt: 2 }}
            >
              Select File
            </Button>
          </label>

          {file && (
            <Typography variant="body1" mt={2}>
              Selected file: {file.name}
            </Typography>
          )}

          {file && (
            <Button
              variant="contained"
              color="secondary"
              onClick={handleUpload}
              disabled={uploading}
              sx={{ mt: 2 }}
            >
              {uploading ? "Uploading..." : "Upload"}
            </Button>
          )}

          {uploading && (
            <CircularProgress />
          )}

          {deleting && (
            <CircularProgress />
          )}

          {/* Display alert message if present */}
          {alertMessage && (
            <Alert
              severity={alertSeverity}
              onClose={() => setAlertMessage(null)}
              sx={{ mt: 2, mb: 2 }}
            >
              {alertMessage}
            </Alert>
          )}
        </Box>

          <Container>
            <Typography variant="h5" gutterBottom>
              Your Uploaded Files
            </Typography>
            <Paper sx={{ height: 500, width: "100%"}}>
              <DataGrid
                rows={files
                  .map((file, index) => ({
                    id: file.id || index,
                    fileName: file.fileName,
                    uploadDate: dayjs(file.uploadDate).format(
                      "DD/MM/YYYY HH:mm:ss"
                    ),
                    filePath: file.filePath,
                  }))}
                columns={columns}
          
                initialState={{
                  sorting: {
                    sortModel: [{ field: "uploadDate", sort: "asc" }],
                  },
                  pagination: {
                    paginationModel: { pageSize: 25, page: 0 },
                  },
                }}

              />
            </Paper>
          </Container>
        

      </Box>

      {/* Footer */}
      <Footer />
    </Box>
  );
};

export default UploadFiles;
