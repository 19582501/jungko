// src/components/Home.tsx
import { useState, useEffect } from "react";
import { Box, CircularProgress } from "@mui/material";
import Footer from "./Footer";
import { ref, getDownloadURL } from "firebase/storage";
import { storage } from "../firebaseConfig";

const Home = () => {
  const [gifUrl, setGifUrl] = useState<string | null>(null);

  useEffect(() => {
    // Get a reference to the Firebase Storage service
    const gifRef = ref(storage, "welcome-sone.gif");

    // Fetch the download URL for the GIF
    getDownloadURL(gifRef)
      .then((url) => {
        setGifUrl(url); // Set the URL when it's fetched
      })
      .catch((error) => {
        console.error("Error fetching GIF from Firebase Storage:", error);
      });
  }, []);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      {/* Main Content */}
      <Box sx={{ flex: "1 0 auto", padding: 4 }}>
        <Box textAlign="center" mb={4}>
          {/* Welcome GIF */}
          {gifUrl ? (
            <img
              src={gifUrl}
              alt="Welcome to S-ONE"
              style={{ maxWidth: "1100px", width: "90%", borderRadius: "8px" }}
            />
          ) : (
            <CircularProgress />
          )}
        </Box>
      </Box>

      {/* Footer */}
      <Footer />
    </Box>
  );
};

export default Home;
