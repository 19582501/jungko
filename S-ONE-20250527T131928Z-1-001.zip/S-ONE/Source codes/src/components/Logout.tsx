import { auth } from "../firebaseConfig";
import { signOut } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import "../index.css";
import { useEffect } from "react";

const Logout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const logout = async () => {
      try {
        await signOut(auth);
      } catch (err) {
        console.log(err);
      } finally {
        navigate("/login");
      }
    };
    logout();
  }, [navigate]);

  return null;
};

export default Logout;
