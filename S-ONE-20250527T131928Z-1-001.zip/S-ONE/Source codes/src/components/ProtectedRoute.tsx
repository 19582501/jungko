import React, { ReactNode, useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { Alert } from "@mui/material";

interface ProtectedRouteProps {
  isAuthenticated: boolean;
  allowedRoles?: string[]; // Allow multiple roles
  userRole?: string; // The role of the current user
  children: ReactNode; // Accepts the children component
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  isAuthenticated,
  allowedRoles = [""],
  userRole = "",
  children,
}) => {
  
  const [redirectToHome, setRedirectToHome] = useState(false);
  const location = useLocation(); // Get the current location
  console.log(location.pathname)

  // Check if the user's role is allowed to access this route
  const isAuthorized = allowedRoles.includes(userRole);

  useEffect(() => {
    if (!isAuthorized) {
      const timer = setTimeout(() => {
        setRedirectToHome(true);
      }, 3000); // 3 seconds delay

      return () => clearTimeout(timer); // Cleanup the timer on unmount
    }
  }, [isAuthorized]);

  if (!isAuthenticated) {
    // If the user is not authenticated, redirect to the login page
    return <Navigate to={`/login?redirect=${location.pathname}`} replace />;
  }

  // If the user is authenticated but not authorized, show an alert and redirect
  if (!isAuthorized) {
    return (
      <>
        <Alert
          severity="error"
          sx={{ position: "relative", top: 16, left: "50%", transform: "translateX(-50%)", width: "90%" }}
          role="alert"
        >
          Access Denied: You do not have permission to view this page. Redirecting to Home...
        </Alert>
        {redirectToHome && <Navigate to="/" />}
      </>
    );
  }

  // If authenticated and authorized, render the children (protected component)
  return <>{children}</>;
};

export default ProtectedRoute;
