import { useEffect, useState } from "react";
import { db, auth } from "../firebaseConfig";
import { collection, getDocs, doc, updateDoc, getDoc } from "firebase/firestore";
import { Box, Typography, Button, Container, Paper, Alert, CircularProgress } from "@mui/material";
import { DataGrid, GridColDef, GridRenderCellParams } from "@mui/x-data-grid";
import Footer from "./Footer";

// Define the structure of a user document
interface User {
  id: string;
  accountStatus: string;
  firstName: string;
  lastName: string;
  email: string;
  accountType: string;
}

const AdminPanel = () => {
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [successMessage, setSuccessMessage] = useState("");
  const [currentUser, setCurrentUser] = useState<{
    firstName: string;
    accountType: string;
  } | null>(null);

  // Fetch the currently logged-in user's data to check if they are an admin
  useEffect(() => {
    const fetchCurrentUser = async () => {
      const user = auth.currentUser;
      if (user) {
        const userRef = doc(db, "users", user.uid);
        const userDoc = await getDoc(userRef);
        if (userDoc.exists()) {
          const userData = userDoc.data();
          setCurrentUser({
            firstName: userData.firstName,
            accountType: userData.accountType,
          });
        }
      }
      setLoading(false);
    };

    fetchCurrentUser();
  }, []);

  // Fetch all users (only if the current user is an admin)
  useEffect(() => {
    const fetchAllUsers = async () => {
      if (currentUser?.accountType === "admin") {
        try {
          setLoading(true);
          const querySnapshot = await getDocs(collection(db, "users"));
          const users = querySnapshot.docs.map(
            (doc) => ({ id: doc.id, ...doc.data() } as User)
          );
          setAllUsers(users);
        } catch (err: any) {
          setError("Failed to fetch users: " + err.message);
        } finally {
          setLoading(false);
        }
      } else if (currentUser) {
        setError("Access Denied: You do not have admin privileges.");
        setLoading(false);
      }
    };

    fetchAllUsers();
  }, [currentUser]);

  // Approve a user
  const handleApprove = async (userId: string) => {
    try {
      const userRef = doc(db, "users", userId);
      await updateDoc(userRef, { accountStatus: "approved" });
      setAllUsers((prevUsers) =>
        prevUsers.map((user) =>
          user.id === userId ? { ...user, accountStatus: "approved" } : user
        )
      );
      setSuccessMessage("User approved successfully!");
    } catch (err: any) {
      setError("Failed to approve user: " + err.message);
    }
  };

  // Reject a user
  const handleReject = async (userId: string) => {
    try {
      const userRef = doc(db, "users", userId);
      await updateDoc(userRef, { accountStatus: "rejected" });
      setAllUsers((prevUsers) =>
        prevUsers.map((user) =>
          user.id === userId ? { ...user, accountStatus: "rejected" } : user
        )
      );
      setSuccessMessage("User rejected successfully!");
    } catch (err: any) {
      setError("Failed to reject user: " + err.message);
    }
  };
  
  if (loading) {
    return <CircularProgress sx={{ display: "block", margin: "auto", mt: 5 }} />;
  }

  // Custom sorting logic for "accountStatus" column
  const accountStatusOrder = {
    pending: 1,
    approved: 2,
    rejected: 3,
  };

  const columns: GridColDef[] = [
    { field: "firstName", headerName: "First Name", flex: 1, sortable: false },
    { field: "lastName", headerName: "Last Name", flex: 1, sortable: false },
    { field: "email", headerName: "Email", flex: 2 },
    { field: "accountType", headerName: "Account Type", flex: 1 },
    {
      field: "accountStatus",
      headerName: "Account Status",
      flex: 1,
      sortComparator: (v1, v2, param1, param2) => {
        const order1 = accountStatusOrder[v1 as keyof typeof accountStatusOrder];
        const order2 = accountStatusOrder[v2 as keyof typeof accountStatusOrder];

        // First compare by status priority
        if (order1 !== order2) {
          return order1 - order2;
        }

        // If status is the same, sort by first name
        const firstName1 = param1.api.getCellValue(param1.id, "firstName") as string;
        const firstName2 = param2.api.getCellValue(param2.id, "firstName") as string;
        return firstName1.localeCompare(firstName2);
      },
    },
    {
      field: "actions",
      headerName: "Actions",
      flex: 1.5,
      sortable: false,
      renderCell: (params: GridRenderCellParams) => {
        return (
          <>
            {params.row.accountStatus === "pending" && (
              <>
                <Button
                  variant="contained"
                  color="primary"
                  size="small"
                  onClick={() => handleApprove(params.row.id)}
                  sx={{ mr: 1 }}
                >
                  Approve
                </Button>
                <Button
                  variant="contained"
                  color="secondary"
                  size="small"
                  onClick={() => handleReject(params.row.id)}
                >
                  Reject
                </Button>
              </>
            )}
          </>
        );
      },
    },
  ];

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      <Box sx={{ flex: "1 0 auto", padding: 4 }}>
        <Typography variant="h4" textAlign="center" sx={{ mb: 2 }}>
          Admin User Management
        </Typography>

        <Container>
          {error && <Alert severity="error">{error}</Alert>}
          {successMessage && <Alert severity="success">{successMessage}</Alert>}

          <Paper sx={{ height: 500, width: "100%", mt: 4 }}>
            <DataGrid
              rows={allUsers}
              columns={columns}
              pageSizeOptions={[10, 25, 50]}
              initialState={{
                pagination: { paginationModel: { pageSize: 25 } },
                sorting: {
                  sortModel: [
                    { field: "accountStatus", sort: "asc" }, // Default sorting by accountStatus
                  ],
                },
              }}
            />
          </Paper>
        </Container>
      </Box>

      {/* Footer */}
      <Footer />
    </Box>
  );
};

export default AdminPanel;
