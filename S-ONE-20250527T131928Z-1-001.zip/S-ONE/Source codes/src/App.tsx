import { Routes, Route } from "react-router-dom";
import { useEffect, useState } from "react";
import Login from "./components/Login";
import Logout from "./components/Logout";
import Register from "./components/Register";
import Home from "./components/Home";
import NSMC_Inventory from "./components/NSMC_Inventory";
import NSMC_NDA from "./components/NSMC_NDA";
import NSMC_NDA_Request from "./components/NSMC_NDA_Request";
import NSMC_SAT_DB from "./components/NSMC_SAT_DB";
import NSMC_Incountry from "./components/NSMC_Incountry";
import NSMC_Import_Export from "./components/NSMC_Import_Export";
import UploadFiles from "./components/UploadFiles";
import FileStorage from "./components/FileStorage";
import AdminPanel from "./components/AdminPanel";
import ProtectedRoute from "./components/ProtectedRoute";
import DenyAccess from "./components/DenyAccess";
import Header from "./components/Header";
import useSessionHandler from "./components/useSessionHandler";
import { auth, db } from "./firebaseConfig";
import { doc, getDoc } from "firebase/firestore";
import { LinearProgress } from "@mui/material";
import "./index.css";
import Page2 from "./components/Page2"
function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<string>("");
  const [firstName, setFirstName] = useState<string>("");
  const [emailVerified, setEmailVerified] = useState(false);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user) {
        setIsAuthenticated(true);
        setEmailVerified(user.emailVerified);

        // Fetch user data from Firestore
        const userDoc = doc(db, "users", user.uid);
        const docSnap = await getDoc(userDoc);
        if (docSnap.exists()) {
          const userData = docSnap.data();
          setUserRole(userData.accountType);
          setFirstName(userData.firstName);
        }
      } else {
        setIsAuthenticated(false);
        setUserRole("");
        setFirstName("");
        setEmailVerified(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  useSessionHandler(); // Activate session handling (inactivity + page unload)

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen">
        <LinearProgress
          sx={{ width: "100%", height: "20px", marginTop: "20px" }}
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      {isAuthenticated && emailVerified && !loading && (
        <Header firstName={firstName} userRole={userRole} />
      )}
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/logout" element={<Logout />} />
        <Route path="/register" element={<Register />} />
        <Route path="/denyaccess" element={<DenyAccess />} />
        <Route path="/page2" element={<Page2 />} />
        <Route
          path="/"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin", "Individual", "GISTDA"]}
            >
              <Home />
            </ProtectedRoute>
          }
        />

        <Route
          path="/nsmc-inventory"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin", "GISTDA"]}
            >
              <NSMC_Inventory />
            </ProtectedRoute>
          }
        />

        <Route
          path="/nsmc-nda"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin", "GISTDA"]}
            >
              <NSMC_NDA />
            </ProtectedRoute>
          }
        />

        <Route
          path="/nsmc-nda/request"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin", "GISTDA"]}
            >
              <NSMC_NDA_Request />
            </ProtectedRoute>
          }
        />

        <Route
          path="/nsmc-sat-db"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin", "GISTDA"]}
            >
              <NSMC_SAT_DB />
            </ProtectedRoute>
          }
        />

        <Route
          path="/nsmc-incountry"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin", "GISTDA"]}
            >
              <NSMC_Incountry />
            </ProtectedRoute>
          }
        />

        <Route
          path="/nsmc-import-export"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin", "GISTDA"]}
            >
              <NSMC_Import_Export />
            </ProtectedRoute>
          }
        />

        <Route
          path="/upload-file"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin", "Individual", "GISTDA"]}
            >
              <UploadFiles />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin"]}
            >
              <AdminPanel />
            </ProtectedRoute>
          }
        />
        <Route
          path="/file-storage"
          element={
            <ProtectedRoute
              isAuthenticated={isAuthenticated && emailVerified}
              userRole={userRole}
              allowedRoles={["admin"]}
            >
              <FileStorage />
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
